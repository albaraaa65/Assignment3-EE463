#include <stdio.h>

int main() {
    char alphabet[26] = "abcdefghijklmnopqrstuvwxyz"; // Define the alphabet
    int count = 0; // Variable to keep track of the number of combinations

    // First loop for the first letter of the password
    for (int i = 0; i < 26; i++) {
        // Second loop for the second letter
        for (int j = 0; j < 26; j++) {
            if (j == i) continue; // Skip if the second letter is the same as the first

            // Third loop for the third letter
            for (int k = 0; k < 26; k++) {
                if (k == i || k == j) continue; // Skip if the third letter is the same as the first or second

                // Fourth loop for the fourth letter
                for (int l = 0; l < 26; l++) {
                    if (l == i || l == j || l == k) continue; // Skip if the fourth letter is the same as any previous letters

                    // Print the combination
                    printf("%c%c%c%c\n", alphabet[i], alphabet[j], alphabet[k], alphabet[l]);
                    count++; // Increment the count for each valid combination
                }
            }
        }
    }

    // Print the total number of combinations
    printf("Total possible combinations for a 4-letter password: %d\n", count);
    return 0;
}
