/*
* Author:
* Description:
* RSA Decryption using OpenSSL library and Python encode/decode
* */
#include <stdio.h>
#include <string.h>
#include <openssl/bn.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

void printBN(char *msg, BIGNUM *tmp){
    char *number_str = BN_bn2hex(tmp); // Convert BIGNUM to hex
    printf("%s%s\n", msg, number_str); // Print hex
    OPENSSL_free(number_str); // Free memory
}

int main(int argc, char *argv[]){
    BN_CTX *ctx = BN_CTX_new();
/*
* Here initialize all needed BIGNUM variables
* 1- Encryption Key variable
* 2- Decryption Key variable
* 3- product of large prime numbers p and q
* 4- Totient of (n) Euler's totient function
* 5- Encrypted Message variable
* 6- Decrypted Ciphertext variable
* */
    BIGNUM *e = BN_new();
    BIGNUM *d = BN_new();
    BIGNUM *n = BN_new();
    BIGNUM *Phi_n = BN_new();
    BIGNUM *C = BN_new(); 
    BIGNUM *D = BN_new();

// Find Decryption Key (d) using (e) and (Phin):
// 1- Assign value to (e) Encryption Key from hex
// 2- Assign value to (Phin) Encryption Key from hex
// 3- Calculate the Decryption Key (Private Key) d=e mod(Phi(n))

    BN_hex2bn(&e, "Your_E_Hex_Value");
    BN_hex2bn(&Phi_n, "Your_Phi_n_Hex_Value");
    BN_hex2bn(&n, "Your_N_Hex_Value");
    BN_mod_inverse(d, e, Phi_n, ctx);


char *CC= malloc(100 * sizeof(char));
printf("\nEnter your Encrypted Message:\n");
// Read the Encrypted Message from the user to variable CC

// Assign the input value in variable (CC) to Encrypted Message variable

    scanf("%s", CC);
    BN_hex2bn(&C, CC);


/*
Decrypt ciphertext using D=C^d(mod(n)) ,
where: (D) is the Decrypted Ciphertext and (C) is the Ciphertext
*/
// Assign value to (n) product of two large prime numbers from hex

    BN_hex2bn(&n, "Your_N_Hex_Value");

// decrypt Ciphertext using the Private Key

    BN_mod_exp(D, C, d, n, ctx);


// Convert Hex string to ASCII letters
    printf("\nOriginal Message:\n");
    char str1[500]="print(\"";
    char *str2 = BN_bn2hex(D);
    char str3[]="\".decode(\"hex\"))";
    strcat(str1,str2);
    strcat(str1,str3);
    char* args[]={"python2", "-c",str1, NULL};
    execvp("python2", args);

    BN_free(e);
    BN_free(d);
    BN_free(n);
    BN_free(Phi_n);
    BN_free(C);
    BN_free(D);
    BN_CTX_free(ctx);
    return EXIT_SUCCESS;
}